{ pkgs }: {
  deps = [
    pkgs.jdk21
    pkgs.gradle
    pkgs.zip
    pkgs.curl
  ];
}
