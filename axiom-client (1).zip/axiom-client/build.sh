#!/bin/bash
set -e

echo "================================================"
echo "  AXIOM CLIENT BUILD"
echo "================================================"

# Give Gradle permission
chmod +x gradlew 2>/dev/null || true

echo ""
echo "[1/3] Building Axiom Client mod..."
gradle build --no-daemon -q

echo "[2/3] Copying mod jar to launcher resources..."
mkdir -p ../axiom-launcher/src/main/resources
cp build/libs/axiomclient-1.0.0.jar ../axiom-launcher/src/main/resources/

echo "[3/3] Building Axiom Launcher..."
cd ../axiom-launcher
gradle jar --no-daemon -q

echo ""
echo "================================================"
echo "  BUILD COMPLETE"
echo "  Output: axiom-launcher/build/libs/axiom-launcher-1.0.0.jar"
echo "  Run with: java -jar build/libs/axiom-launcher-1.0.0.jar"
echo "================================================"
