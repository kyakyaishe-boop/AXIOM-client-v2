package com.axiom.client.module.modules.misc;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;

public class NoSlow extends Module {

    public NoSlow() {
        super("NoSlow", Category.MISC);
    }
    // Handled via mixin on PlayerEntity.getMovementSpeed() — reads this module's state
}
