package com.axiom.client.module.modules.combat;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class Triggerbot extends Module {

    private static final int BASE_DELAY   = 8;
    private static final int DELAY_JITTER = 4;
    private static final int JUMP_TICK    = 3;

    private int     ticksSinceAttack = 0;
    private int     currentDelay     = BASE_DELAY;
    private boolean jumping          = false;
    private int     jumpTick         = 0;

    public Triggerbot() {
        super("Triggerbot", Category.COMBAT);
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient mc) {
        if (!isEnabled()) return;
        if (mc.player == null || mc.world == null) return;

        ticksSinceAttack++;

        HitResult hit = mc.crosshairTarget;
        if (hit == null || hit.getType() != HitResult.Type.ENTITY) return;

        Entity target = ((EntityHitResult) hit).getEntity();
        if (!(target instanceof LivingEntity)) return;
        if (target instanceof PlayerEntity p && p == mc.player) return;
        if (!((LivingEntity) target).isAlive()) return;

        float cooldown = mc.player.getAttackCooldownProgress(0f);
        if (cooldown < 1.0f) return;
        if (ticksSinceAttack < currentDelay) return;

        if (shouldCrit(mc)) {
            if (!jumping && mc.player.isOnGround()) {
                mc.player.jump();
                jumping  = true;
                jumpTick = 0;
                return;
            }
            if (jumping) {
                jumpTick++;
                if (jumpTick >= JUMP_TICK && mc.player.getVelocity().y < 0) {
                    attack(mc, target);
                    jumping = false; jumpTick = 0;
                }
                return;
            }
        }

        attack(mc, target);
    }

    private void attack(MinecraftClient mc, Entity target) {
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        ticksSinceAttack = 0;
        currentDelay = BASE_DELAY + (int)(Math.random() * DELAY_JITTER);
    }

    private boolean shouldCrit(MinecraftClient mc) {
        if (mc.player == null) return false;
        return mc.player.isOnGround()
                && !mc.player.isTouchingWater()
                && !mc.player.isInLava()
                && !mc.player.isClimbing()
                && mc.player.getStatusEffect(StatusEffects.BLINDNESS) == null;
    }
}
