package com.axiom.client.module.modules.combat;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;

public class Reach extends Module {

    public static final double REACH_DISTANCE = 6.0;

    public Reach() {
        super("Reach", Category.COMBAT);
    }
}
