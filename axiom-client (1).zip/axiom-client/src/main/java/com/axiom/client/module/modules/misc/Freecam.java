package com.axiom.client.module.modules.misc;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;

public class Freecam extends Module {

    private Perspective prevPerspective;

    public Freecam() {
        super("Freecam", Category.MISC);
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        prevPerspective = mc.options.getPerspective();
        mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        mc.player.setNoGravity(true);
    }

    @Override
    public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        mc.options.setPerspective(prevPerspective != null ? prevPerspective : Perspective.FIRST_PERSON);
        mc.player.setNoGravity(false);
    }
}
