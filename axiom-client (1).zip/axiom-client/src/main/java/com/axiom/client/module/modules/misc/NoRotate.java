package com.axiom.client.module.modules.misc;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;

public class NoRotate extends Module {

    public NoRotate() {
        super("NoRotate", Category.MISC);
    }
    // Handled via mixin — blocks incoming server rotation packets when enabled
}
