package com.axiom.client.module.modules.misc;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public class ChatSpam extends Module {

    private static final String MESSAGE      = "axiom client";
    private static final int    INTERVAL     = 100; // ticks between messages
    private int tick = 0;

    public ChatSpam() {
        super("ChatSpam", Category.MISC);
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient mc) {
        if (!isEnabled()) return;
        if (mc.player == null || mc.getNetworkHandler() == null) return;
        tick++;
        if (tick >= INTERVAL) {
            mc.player.networkHandler.sendChatMessage(MESSAGE);
            tick = 0;
        }
    }
}
