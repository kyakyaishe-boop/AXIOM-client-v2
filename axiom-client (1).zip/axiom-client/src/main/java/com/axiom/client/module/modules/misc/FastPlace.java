package com.axiom.client.module.modules.misc;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public class FastPlace extends Module {

    public FastPlace() {
        super("FastPlace", Category.MISC);
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient mc) {
        if (!isEnabled()) return;
        if (mc.player == null) return;
        mc.player.getItemCooldownManager().set(
                mc.player.getMainHandStack().getItem(), 0
        );
    }
}
