package com.axiom.client.gui;

import com.axiom.client.AxiomClient;
import com.axiom.client.module.Category;
import com.axiom.client.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

public class ClickGUI extends Screen {

    private static final int PANEL_W      = 90;
    private static final int HEADER_H     = 14;
    private static final int MODULE_H     = 13;
    private static final int PANEL_START_X = 8;
    private static final int PANEL_START_Y = 8;
    private static final int PANEL_GAP    = 4;

    // Category header colors (ARGB)
    private static final int[] HEADER_COLORS = {
        0xFFc0392b,  // COMBAT   — red
        0xFF1a6ea8,  // VISUALS  — blue
        0xFF2d6a4f,  // MISC     — green
        0xFF6c3483   // BLATANT  — purple
    };

    private static final int BG_MODULE_OFF  = 0xCC12121f;
    private static final int BG_MODULE_ON   = 0xCC1a1a38;
    private static final int TEXT_OFF       = 0xFF9090b0;
    private static final int TEXT_ON        = 0xFFe0e0ff;
    private static final int DIVIDER        = 0x22ffffff;

    private final Category[] categories = {
        Category.COMBAT, Category.VISUALS, Category.MISC, Category.BLATANT
    };

    public ClickGUI() {
        super(Text.literal("Axiom"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Dim background
        ctx.fill(0, 0, this.width, this.height, 0x55000000);

        for (int ci = 0; ci < categories.length; ci++) {
            Category cat = categories[ci];
            int px = PANEL_START_X + ci * (PANEL_W + PANEL_GAP);
            int py = PANEL_START_Y;

            // Header
            ctx.fill(px, py, px + PANEL_W, py + HEADER_H, HEADER_COLORS[ci]);
            ctx.drawCenteredTextWithShadow(textRenderer,
                    cat.name(), px + PANEL_W / 2, py + 3, 0xFFFFFFFF);

            // Modules
            List<Module> mods = AxiomClient.getInstance()
                    .getModuleManager().getByCategory(cat);

            for (int mi = 0; mi < mods.size(); mi++) {
                Module mod = mods.get(mi);
                int my = py + HEADER_H + mi * MODULE_H;
                boolean on = mod.isEnabled();

                ctx.fill(px, my, px + PANEL_W, my + MODULE_H,
                        on ? BG_MODULE_ON : BG_MODULE_OFF);

                // Bottom divider
                ctx.fill(px, my + MODULE_H - 1, px + PANEL_W, my + MODULE_H, DIVIDER);

                // Module name
                ctx.drawTextWithShadow(textRenderer,
                        mod.getName(), px + 5, my + 3,
                        on ? TEXT_ON : TEXT_OFF);

                // Toggle pill
                int pillX = px + PANEL_W - 18;
                int pillY = my + 3;
                int pillW = 14;
                int pillH = 7;
                int pillBg   = on ? HEADER_COLORS[ci] : 0xFF2a2a4a;
                int knobX    = on ? pillX + pillW - 6 : pillX + 1;

                ctx.fill(pillX, pillY, pillX + pillW, pillY + pillH, pillBg);
                ctx.fill(knobX, pillY + 1, knobX + 5, pillY + pillH - 1, 0xFFFFFFFF);
            }
        }

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);

        for (int ci = 0; ci < categories.length; ci++) {
            Category cat = categories[ci];
            int px = PANEL_START_X + ci * (PANEL_W + PANEL_GAP);
            int py = PANEL_START_Y + HEADER_H;

            List<Module> mods = AxiomClient.getInstance()
                    .getModuleManager().getByCategory(cat);

            for (int mi = 0; mi < mods.size(); mi++) {
                int modY = py + mi * MODULE_H;
                if (mx >= px && mx <= px + PANEL_W
                        && my >= modY && my <= modY + MODULE_H) {
                    mods.get(mi).toggle();
                    return true;
                }
            }
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override public boolean shouldPause() { return false; }
}
