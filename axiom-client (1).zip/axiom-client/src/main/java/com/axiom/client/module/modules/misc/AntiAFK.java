package com.axiom.client.module.modules.misc;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

public class AntiAFK extends Module {

    private int tick = 0;

    public AntiAFK() {
        super("AntiAFK", Category.MISC);
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient mc) {
        if (!isEnabled()) return;
        if (mc.player == null) return;
        tick++;
        // Rotate 5 degrees every 40 ticks — sub-perceptible, breaks AFK detection
        if (tick % 40 == 0) {
            mc.player.setYaw(mc.player.getYaw() + 5f);
        }
        // Jump every 200 ticks
        if (tick % 200 == 0 && mc.player.isOnGround()) {
            mc.player.jump();
        }
    }
}
