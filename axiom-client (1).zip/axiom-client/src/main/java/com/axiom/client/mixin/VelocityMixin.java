package com.axiom.client.mixin;

import com.axiom.client.AxiomClient;
import com.axiom.client.module.modules.combat.Velocity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class VelocityMixin {

    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void cancelVelocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        Velocity velocity = (Velocity) AxiomClient.getInstance()
                .getModuleManager().getByName("Velocity");
        if (velocity == null || !velocity.isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && packet.getEntityId() == mc.player.getId()) {
            ci.cancel();
        }
    }
}
