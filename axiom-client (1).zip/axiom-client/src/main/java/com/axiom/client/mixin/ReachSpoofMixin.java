package com.axiom.client.mixin;

import com.axiom.client.AxiomClient;
import com.axiom.client.module.modules.combat.Reach;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerInteractionManager.class)
public class ReachSpoofMixin {

    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true)
    private void clampReachDistance(PlayerEntity player, Entity target, CallbackInfo ci) {
        Reach reach = (Reach) AxiomClient.getInstance()
                .getModuleManager().getByName("Reach");
        if (reach == null || !reach.isEnabled()) return;
        double dist = player.getPos().distanceTo(target.getPos());
        if (dist > 3.5) ci.cancel();
    }
}
