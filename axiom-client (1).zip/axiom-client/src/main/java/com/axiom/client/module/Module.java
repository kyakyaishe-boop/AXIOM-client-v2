package com.axiom.client.module;

public abstract class Module {

    private final String name;
    private final Category category;
    private boolean enabled = false;

    public Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    public void onEnable()  {}
    public void onDisable() {}
    public void onTick()    {}

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable();
        else onDisable();
    }

    public String   getName()       { return name; }
    public Category getCategory()   { return category; }
    public boolean  isEnabled()     { return enabled; }
    public void     setEnabled(boolean state) { this.enabled = state; }
}
