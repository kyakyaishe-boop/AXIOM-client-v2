package com.axiom.client.module.modules.visuals;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import org.joml.Matrix4f;

import java.util.List;

public class ESP extends Module {

    private static final int COLOR_R = 255, COLOR_G = 0, COLOR_B = 0, COLOR_A = 200;

    public ESP() {
        super("ESP", Category.VISUALS);
    }

    @Override
    public void onEnable() {
        WorldRenderEvents.AFTER_ENTITIES.register(this::onWorldRender);
    }

    private void onWorldRender(WorldRenderContext ctx) {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        MatrixStack matrices = ctx.matrixStack();
        VertexConsumerProvider consumers = ctx.consumers();
        if (matrices == null || consumers == null) return;

        List<PlayerEntity> players = mc.world.getEntitiesByClass(
                PlayerEntity.class,
                mc.player.getBoundingBox().expand(128),
                e -> e != mc.player && !e.isInvisible()
        );

        matrices.push();
        Camera cam = ctx.camera();
        matrices.translate(-cam.getPos().x, -cam.getPos().y, -cam.getPos().z);

        for (PlayerEntity player : players) {
            drawESPBox(matrices, consumers, player.getBoundingBox());
        }

        matrices.pop();
    }

    private void drawESPBox(MatrixStack matrices, VertexConsumerProvider consumers, Box box) {
        VertexConsumer buffer = consumers.getBuffer(RenderLayer.LINES);
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        float x1 = (float) box.minX, y1 = (float) box.minY, z1 = (float) box.minZ;
        float x2 = (float) box.maxX, y2 = (float) box.maxY, z2 = (float) box.maxZ;
        float r = COLOR_R/255f, g = COLOR_G/255f, b = COLOR_B/255f, a = COLOR_A/255f;

        line(buffer,matrix, x1,y1,z1, x2,y1,z1, r,g,b,a);
        line(buffer,matrix, x2,y1,z1, x2,y1,z2, r,g,b,a);
        line(buffer,matrix, x2,y1,z2, x1,y1,z2, r,g,b,a);
        line(buffer,matrix, x1,y1,z2, x1,y1,z1, r,g,b,a);
        line(buffer,matrix, x1,y2,z1, x2,y2,z1, r,g,b,a);
        line(buffer,matrix, x2,y2,z1, x2,y2,z2, r,g,b,a);
        line(buffer,matrix, x2,y2,z2, x1,y2,z2, r,g,b,a);
        line(buffer,matrix, x1,y2,z2, x1,y2,z1, r,g,b,a);
        line(buffer,matrix, x1,y1,z1, x1,y2,z1, r,g,b,a);
        line(buffer,matrix, x2,y1,z1, x2,y2,z1, r,g,b,a);
        line(buffer,matrix, x2,y1,z2, x2,y2,z2, r,g,b,a);
        line(buffer,matrix, x1,y1,z2, x1,y2,z2, r,g,b,a);
    }

    private void line(VertexConsumer buf, Matrix4f m,
                      float x1, float y1, float z1,
                      float x2, float y2, float z2,
                      float r, float g, float b, float a) {
        buf.vertex(m, x1, y1, z1).color(r,g,b,a).normal(0,1,0).next();
        buf.vertex(m, x2, y2, z2).color(r,g,b,a).normal(0,1,0).next();
    }
}
