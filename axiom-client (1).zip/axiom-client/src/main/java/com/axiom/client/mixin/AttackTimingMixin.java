package com.axiom.client.mixin;

import com.axiom.client.AxiomClient;
import com.axiom.client.module.modules.combat.Triggerbot;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerInteractionManager.class)
public class AttackTimingMixin {

    private long lastAttackMs = 0;
    private static final java.util.Random random = new java.util.Random();

    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true)
    private void jitterAttackTiming(PlayerEntity player, Entity target, CallbackInfo ci) {
        Triggerbot tb = (Triggerbot) AxiomClient.getInstance()
                .getModuleManager().getByName("Triggerbot");
        if (tb == null || !tb.isEnabled()) return;

        long now   = System.currentTimeMillis();
        long delta = now - lastAttackMs;
        double jitter = 110 + (random.nextGaussian() * 18);
        if (delta < (long) jitter) {
            ci.cancel();
            return;
        }
        lastAttackMs = now;
    }
}
