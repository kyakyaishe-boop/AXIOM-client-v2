package com.axiom.client.module;

public enum Category {
    COMBAT,
    VISUALS,
    MISC,
    BLATANT
}
