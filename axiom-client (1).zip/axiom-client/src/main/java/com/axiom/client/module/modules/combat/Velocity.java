package com.axiom.client.module.modules.combat;

import com.axiom.client.module.Category;
import com.axiom.client.module.Module;

public class Velocity extends Module {

    public Velocity() {
        super("Velocity", Category.COMBAT);
    }
}
