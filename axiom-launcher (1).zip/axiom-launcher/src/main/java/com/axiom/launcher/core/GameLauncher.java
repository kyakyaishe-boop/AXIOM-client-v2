package com.axiom.launcher.core;

import com.axiom.launcher.auth.MojangAuth;
import com.axiom.launcher.installer.FabricInstaller;
import com.google.gson.*;
import okhttp3.*;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class GameLauncher {

    private static final String VERSION_MANIFEST =
            "https://launchermeta.mojang.com/mc/game/version_manifest.json";
    private static final OkHttpClient HTTP = new OkHttpClient.Builder()
            .readTimeout(120, java.util.concurrent.TimeUnit.SECONDS)
            .build();
    private static final Gson GSON = new Gson();

    public static void launch(MojangAuth.Session session, String mcVersion)
            throws Exception {

        Path minecraftDir = FabricInstaller.getMinecraftDir();
        String loaderVer  = com.axiom.launcher.AxiomLauncher.LOADER_VER;
        String profileId  = "fabric-loader-" + loaderVer + "-" + mcVersion;

        // Load Fabric profile JSON
        Path profileJson = minecraftDir
                .resolve("versions")
                .resolve(profileId)
                .resolve(profileId + ".json");

        if (!Files.exists(profileJson)) {
            throw new IOException("Fabric profile not found at " + profileJson);
        }

        JsonObject profile = GSON.fromJson(
                Files.readString(profileJson), JsonObject.class);

        // Build classpath from libraries
        List<String> classpath = buildClasspath(profile, minecraftDir, mcVersion);

        // Main class is Fabric's knot launcher
        String mainClass = profile.get("mainClass").getAsString();

        // Build JVM arguments
        List<String> cmd = new ArrayList<>();
        cmd.add(FabricInstaller.getMinecraftDir()
                .resolve("..").resolve("..").toString()); // placeholder
        cmd.clear();

        String javaExec = getJavaExecutable(minecraftDir);
        cmd.add(javaExec);

        // JVM flags — memory, rendering
        cmd.add("-Xmx2G");
        cmd.add("-Xms512M");
        cmd.add("-XX:+UseG1GC");
        cmd.add("-XX:+UnlockExperimentalVMOptions");
        cmd.add("-XX:G1NewSizePercent=20");
        cmd.add("-XX:G1ReservePercent=20");
        cmd.add("-XX:MaxGCPauseMillis=50");
        cmd.add("-XX:G1HeapRegionSize=32M");
        cmd.add("-Djava.library.path=" +
                minecraftDir.resolve("versions")
                            .resolve(mcVersion)
                            .resolve("natives")
                            .toAbsolutePath());
        cmd.add("-Dminecraft.launcher.brand=axiom-launcher");
        cmd.add("-Dminecraft.launcher.version=" +
                com.axiom.launcher.AxiomLauncher.VERSION);

        // Classpath
        cmd.add("-cp");
        cmd.add(String.join(File.pathSeparator, classpath));

        // Main class
        cmd.add(mainClass);

        // Game arguments
        cmd.add("--username");    cmd.add(session.username);
        cmd.add("--version");     cmd.add(profileId);
        cmd.add("--gameDir");     cmd.add(minecraftDir.toAbsolutePath().toString());
        cmd.add("--assetsDir");   cmd.add(minecraftDir.resolve("assets").toAbsolutePath().toString());
        cmd.add("--assetIndex");  cmd.add(mcVersion);
        cmd.add("--uuid");        cmd.add(session.uuid);
        cmd.add("--accessToken"); cmd.add(session.accessToken);
        cmd.add("--userType");    cmd.add("mojang");
        cmd.add("--versionType"); cmd.add("release");

        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.directory(minecraftDir.toFile());
        pb.redirectErrorStream(true);
        pb.inheritIO(); // pipe game output to launcher console

        pb.start();
        // Don't waitFor — game runs independently, launcher stays open
    }

    private static List<String> buildClasspath(
            JsonObject profile, Path minecraftDir, String mcVersion) throws Exception {

        List<String> cp = new ArrayList<>();
        Path librariesDir = minecraftDir.resolve("libraries");

        // Fabric + inherited libraries
        JsonArray libs = profile.getAsJsonArray("libraries");
        if (libs != null) {
            for (JsonElement el : libs) {
                JsonObject lib = el.getAsJsonObject();
                if (!lib.has("downloads")) {
                    // Fabric-specific lib — resolve by name
                    String name = lib.get("name").getAsString();
                    Path p = mavenPathFromName(librariesDir, name);
                    if (Files.exists(p)) cp.add(p.toAbsolutePath().toString());
                    continue;
                }
                JsonObject artifact = lib.getAsJsonObject("downloads")
                                         .getAsJsonObject("artifact");
                if (artifact == null) continue;
                String path = artifact.get("path").getAsString();
                Path full = librariesDir.resolve(path.replace("/", File.separator));
                if (Files.exists(full)) cp.add(full.toAbsolutePath().toString());
            }
        }

        // Minecraft client jar
        Path clientJar = minecraftDir.resolve("versions")
                                      .resolve(mcVersion)
                                      .resolve(mcVersion + ".jar");
        if (Files.exists(clientJar)) cp.add(clientJar.toAbsolutePath().toString());

        return cp;
    }

    private static Path mavenPathFromName(Path root, String name) {
        // group:artifact:version → group/artifact/version/artifact-version.jar
        String[] parts = name.split(":");
        if (parts.length < 3) return root.resolve(name);
        String group    = parts[0].replace('.', File.separatorChar);
        String artifact = parts[1];
        String version  = parts[2];
        return root.resolve(group)
                   .resolve(artifact)
                   .resolve(version)
                   .resolve(artifact + "-" + version + ".jar");
    }

    private static String getJavaExecutable(Path minecraftDir) {
        // Prefer Minecraft's bundled JRE if present (Launcher installs it)
        Path jreDir = minecraftDir.resolve("runtime");
        String os   = System.getProperty("os.name").toLowerCase();
        String exe  = os.contains("win") ? "java.exe" : "java";

        try {
            Optional<Path> jreBin = Files.walk(jreDir, 4)
                    .filter(p -> p.getFileName().toString().equals(exe))
                    .findFirst();
            if (jreBin.isPresent()) return jreBin.get().toAbsolutePath().toString();
        } catch (Exception ignored) {}

        return "java"; // fallback to PATH
    }
}
