package com.axiom.launcher.installer;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.*;
import java.net.URI;
import java.nio.file.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class FabricInstaller {

    private static final String FABRIC_INSTALLER_URL =
            "https://maven.fabricmc.net/net/fabricmc/fabric-installer/1.0.1/fabric-installer-1.0.1.jar";

    private static final OkHttpClient HTTP = new OkHttpClient.Builder()
            .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(120, java.util.concurrent.TimeUnit.SECONDS)
            .build();

    public static void ensureInstalled(String mcVersion, String loaderVersion)
            throws Exception {

        Path minecraftDir = getMinecraftDir();
        Path versionsDir  = minecraftDir.resolve("versions");
        String profileId  = "fabric-loader-" + loaderVersion + "-" + mcVersion;
        Path profileDir   = versionsDir.resolve(profileId);

        // Already installed
        if (Files.exists(profileDir.resolve(profileId + ".json"))) return;

        // Download Fabric installer jar
        Path installerJar = minecraftDir.resolve("axiom-fabric-installer.jar");
        if (!Files.exists(installerJar)) {
            downloadFile(FABRIC_INSTALLER_URL, installerJar);
        }

        // Run installer headlessly
        ProcessBuilder pb = new ProcessBuilder(
                getJavaExecutable(),
                "-jar", installerJar.toAbsolutePath().toString(),
                "client",
                "-mcversion", mcVersion,
                "-loader", loaderVersion,
                "-dir", minecraftDir.toAbsolutePath().toString(),
                "-noprofile"
        );
        pb.redirectErrorStream(true);
        Process proc = pb.start();

        // Drain output so process doesn't block
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(proc.getInputStream()))) {
            while (reader.readLine() != null) {}
        }

        int exit = proc.waitFor();
        if (exit != 0) throw new IOException("Fabric installer exited with code " + exit);

        // Clean up installer jar
        Files.deleteIfExists(installerJar);
    }

    public static void deployMod() throws Exception {
        Path modsDir = getMinecraftDir().resolve("mods");
        Files.createDirectories(modsDir);

        Path modDest = modsDir.resolve("axiomclient-1.0.0.jar");
        if (Files.exists(modDest)) return; // already deployed

        // Extract bundled mod jar from launcher resources
        try (InputStream is = FabricInstaller.class
                .getResourceAsStream("/axiomclient-1.0.0.jar")) {
            if (is == null) {
                throw new IOException(
                    "Axiom mod jar not bundled in launcher. " +
                    "Build the client first (gradle build) and place " +
                    "axiomclient-1.0.0.jar in launcher/src/main/resources/");
            }
            Files.copy(is, modDest, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    // --- Utilities ---

    public static Path getMinecraftDir() {
        String os = System.getProperty("os.name").toLowerCase();
        if (os.contains("win")) {
            return Paths.get(System.getenv("APPDATA"), ".minecraft");
        } else if (os.contains("mac")) {
            return Paths.get(System.getProperty("user.home"),
                    "Library", "Application Support", "minecraft");
        } else {
            return Paths.get(System.getProperty("user.home"), ".minecraft");
        }
    }

    private static void downloadFile(String url, Path dest) throws IOException {
        Request req = new Request.Builder().url(url).build();
        try (Response res = HTTP.newCall(req).execute()) {
            if (!res.isSuccessful() || res.body() == null)
                throw new IOException("Download failed: " + url);
            Files.copy(res.body().byteStream(), dest,
                    StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static String getJavaExecutable() {
        String javaHome = System.getProperty("java.home");
        String os = System.getProperty("os.name").toLowerCase();
        String exe = os.contains("win") ? "java.exe" : "java";
        Path candidate = Paths.get(javaHome, "bin", exe);
        return Files.exists(candidate) ? candidate.toAbsolutePath().toString() : "java";
    }
}
