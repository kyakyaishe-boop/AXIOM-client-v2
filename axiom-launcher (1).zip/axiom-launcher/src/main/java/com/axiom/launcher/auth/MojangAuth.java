package com.axiom.launcher.auth;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import okhttp3.*;

import java.io.IOException;

public class MojangAuth {

    private static final String AUTH_URL =
            "https://authserver.mojang.com/authenticate";
    private static final OkHttpClient HTTP  = new OkHttpClient();
    private static final Gson         GSON  = new Gson();
    private static final MediaType    JSON  =
            MediaType.parse("application/json; charset=utf-8");

    public static class Session {
        public final String username;
        public final String uuid;
        public final String accessToken;

        public Session(String username, String uuid, String accessToken) {
            this.username    = username;
            this.uuid        = uuid;
            this.accessToken = accessToken;
        }
    }

    public static Session authenticate(String email, String password)
            throws IOException, AuthException {

        JsonObject agent = new JsonObject();
        agent.addProperty("name", "Minecraft");
        agent.addProperty("version", 1);

        JsonObject payload = new JsonObject();
        payload.add("agent", agent);
        payload.addProperty("username", email);
        payload.addProperty("password", password);
        payload.addProperty("requestUser", false);

        RequestBody body = RequestBody.create(GSON.toJson(payload), JSON);
        Request request  = new Request.Builder()
                .url(AUTH_URL)
                .post(body)
                .addHeader("Content-Type", "application/json")
                .build();

        try (Response response = HTTP.newCall(request).execute()) {
            String raw = response.body() != null ? response.body().string() : "";

            if (!response.isSuccessful()) {
                JsonObject err = GSON.fromJson(raw, JsonObject.class);
                String msg = err.has("errorMessage")
                        ? err.get("errorMessage").getAsString()
                        : "HTTP " + response.code();
                throw new AuthException(msg);
            }

            JsonObject json     = GSON.fromJson(raw, JsonObject.class);
            String accessToken  = json.get("accessToken").getAsString();
            JsonObject profile  = json.getAsJsonObject("selectedProfile");
            String uuid         = profile.get("id").getAsString();
            String username     = profile.get("name").getAsString();

            return new Session(username, uuid, accessToken);
        }
    }

    public static class AuthException extends Exception {
        public AuthException(String msg) { super(msg); }
    }
}
